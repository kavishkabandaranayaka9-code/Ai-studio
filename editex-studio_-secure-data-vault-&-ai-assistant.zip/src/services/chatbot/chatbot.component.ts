import { ChangeDetectionStrategy, Component, input, signal, WritableSignal, ViewChild, ElementRef, AfterViewInit, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GeminiService, ChatMessage } from '../../services/gemini.service';

interface DisplayMessage {
  author: 'user' | 'bot';
  content: string;
}

@Component({
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule]
})
export class ChatbotComponent implements AfterViewInit {
  isOpen = input<boolean>(false);

  messages: WritableSignal<DisplayMessage[]> = signal([
    { author: 'bot', content: 'Hello! How can I help you with your security questions today?' }
  ]);
  userInput = signal('');
  isLoading = signal(false);
  geminiService = new GeminiService();
  error = this.geminiService.error;

  @ViewChild('chatContainer') private chatContainer!: ElementRef;

  constructor() {
    effect(() => {
        if (this.messages().length > 0) {
            this.scrollToBottom();
        }
    });
  }

  ngAfterViewInit() {
    this.scrollToBottom();
  }

  async sendMessage() {
    const message = this.userInput().trim();
    if (!message || this.isLoading()) return;

    // Add user message to UI
    this.messages.update(m => [...m, { author: 'user', content: message }]);
    this.userInput.set('');
    this.isLoading.set(true);

    // Add bot placeholder
    this.messages.update(m => [...m, { author: 'bot', content: '' }]);

    const history: ChatMessage[] = this.messages()
      .slice(0, -2) // Exclude user's latest message and bot placeholder
      .map(m => ({
        role: m.author === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      }));
      
    try {
      const stream = this.geminiService.generateChatResponseStream(history, message);
      for await (const chunk of stream) {
        this.messages.update(m => {
          const lastMessage = m[m.length - 1];
          lastMessage.content += chunk;
          return [...m.slice(0, -1), lastMessage];
        });
        this.scrollToBottom();
      }
    } catch(e) {
      console.error("Failed to process stream", e);
      this.messages.update(m => {
        const lastMessage = m[m.length - 1];
        lastMessage.content = 'Sorry, I encountered an error. Please try again.';
        return [...m.slice(0, -1), lastMessage];
      });
    } finally {
      this.isLoading.set(false);
    }
  }

  private scrollToBottom(): void {
    try {
        setTimeout(() => {
            if (this.chatContainer) {
                this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;
            }
        }, 0);
    } catch (err) {
        console.error("Could not scroll to bottom:", err);
    }
  }
}
