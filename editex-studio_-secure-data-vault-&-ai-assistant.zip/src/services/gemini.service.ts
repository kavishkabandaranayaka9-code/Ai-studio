import { Injectable, signal, WritableSignal } from '@angular/core';
import { GoogleGenAI, Chat, Content } from "@google/genai";
import { environment } from '../../environments/environment';

export interface ChatMessage {
  role: 'user' | 'model';
  parts: { text: string }[];
}

@Injectable({
  providedIn: 'root'
})
export class GeminiService {
  private ai: GoogleGenAI;
  private chat: Chat | null = null;
  error: WritableSignal<string | null> = signal(null);

  constructor() {
    // IMPORTANT: The API key is sourced from environment variables for security.
    // It is assumed that `process.env.API_KEY` is set in the deployment environment.
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      const errorMessage = "API key not found. Please set the API_KEY environment variable.";
      this.error.set(errorMessage);
      console.error(errorMessage);
      // In a real app, you might not want to throw an error here but handle it gracefully.
      // For this applet, we will let it fail to make it clear the API key is missing.
      throw new Error(errorMessage);
    }
    this.ai = new GoogleGenAI({ apiKey });
  }

  private initializeChat(history: ChatMessage[]) {
    this.chat = this.ai.chats.create({
      model: 'gemini-2.5-flash',
      history: history,
      config: {
        systemInstruction: 'You are a friendly and helpful AI assistant for a privacy and security application called Editex Studio. Be concise and clear in your answers.',
      },
    });
  }

  async *generateChatResponseStream(history: ChatMessage[], newMessage: string) {
    this.error.set(null);

    if (!this.chat) {
        this.initializeChat(history);
    }
    
    if(!this.chat) {
        this.error.set("Chat could not be initialized.");
        return;
    }

    try {
      const result = await this.chat.sendMessageStream({ message: newMessage });
      for await (const chunk of result) {
        yield chunk.text;
      }
    } catch (e: any) {
      const errorMessage = "Could not get response from AI. " + (e.message || "Please try again later.");
      this.error.set(errorMessage);
      console.error("Gemini API Error:", e);
    }
  }
}
