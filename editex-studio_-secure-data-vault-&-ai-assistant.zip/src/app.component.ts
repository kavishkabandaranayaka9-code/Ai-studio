import { ChangeDetectionStrategy, Component, signal, WritableSignal, ElementRef, ViewChild, AfterViewInit, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatbotComponent } from './components/chatbot/chatbot.component';

// This informs TypeScript that CryptoJS is a global variable from the script tag in index.html
declare var CryptoJS: any;

type Tab = 'lock' | 'unlock';
type DataType = 'text' | 'image';
type ModalType = 'about' | 'terms' | 'warning' | null;

interface ModalContent {
  title: string;
  content: string[];
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ChatbotComponent]
})
export class AppComponent {
  activeTab: WritableSignal<Tab> = signal('lock');
  dataType: WritableSignal<DataType> = signal('text');
  
  // Encryption state
  encryptPassword = signal('');
  textToEncrypt = signal('');
  fileToEncrypt: WritableSignal<File | null> = signal(null);
  encryptedHash = signal('');
  showEncryptSuccess = signal(false);

  // Decryption state
  hashToDecrypt = signal('');
  decryptPassword = signal('');
  decryptedText = signal('');
  decryptedImage = signal('');
  showDecryptOutput = signal(false);

  // Modal state
  activeModal: WritableSignal<ModalType> = signal(null);

  // Chatbot state
  isChatbotOpen = signal(false);

  private readonly SALT = "UNIQUE_KEY_998877665544";

  readonly modalData: Record<string, ModalContent> = {
    about: {
      title: 'About Editex Studio',
      content: [
        'We are a privacy-first technology provider. Our tools are designed to empower individuals with digital security.',
        'Our "Zero-Knowledge" architecture ensures that your data remains yours alone.'
      ]
    },
    terms: {
      title: 'Terms of Service',
      content: [
        '<b>1. User Compliance:</b> By using this tool, you agree not to encrypt any illegal content.',
        '<b>2. No Liability:</b> Editex Studio is not responsible for any misuse of this encryption technology.',
        '<b>3. Data Recovery:</b> We do not store passwords. If you lose your password, data recovery is impossible.'
      ]
    },
    warning: {
      title: '⚠ User Warning',
      content: [
        '• Do not use this tool for storing illegal materials.',
        '• Any suspicious activity may be subject to local digital privacy laws.',
        '• Editex Studio operates as a tool provider and does not facilitate or encourage illegal data transfer.'
      ]
    }
  };

  constructor() {
    effect(() => {
        // Reset success message when switching tabs
        this.activeTab();
        this.showEncryptSuccess.set(false);
        this.showDecryptOutput.set(false);
    });
    effect(() => {
        // Reset inputs when changing data type
        this.dataType();
        this.textToEncrypt.set('');
        this.fileToEncrypt.set(null);
    });
  }

  showTab(tab: Tab): void {
    this.activeTab.set(tab);
  }

  handleFileInput(event: Event): void {
    const element = event.currentTarget as HTMLInputElement;
    let fileList: FileList | null = element.files;
    if (fileList && fileList.length > 0) {
      this.fileToEncrypt.set(fileList[0]);
    }
  }

  executeLock(): void {
    const password = this.encryptPassword();
    if (!password) {
      alert("Password is required for security.");
      return;
    }
    
    this.showEncryptSuccess.set(false);
    this.encryptedHash.set('');

    if (this.dataType() === 'text') {
      const message = this.textToEncrypt();
      if (!message) {
        alert("Please enter a message to encrypt.");
        return;
      }
      const encrypted = CryptoJS.AES.encrypt(message, password + this.SALT).toString();
      this.encryptedHash.set("STX_TXT" + btoa(encrypted));
      this.showEncryptSuccess.set(true);
    } else {
      const file = this.fileToEncrypt();
      if (!file) {
        alert("Please select a file to encrypt.");
        return;
      }
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const encrypted = CryptoJS.AES.encrypt(e.target.result, password + this.SALT).toString();
        this.encryptedHash.set("STX_IMG" + btoa(encrypted));
        this.showEncryptSuccess.set(true);
      };
      reader.readAsDataURL(file);
    }
  }

  copyHiddenHash(): void {
    if (this.encryptedHash()) {
      navigator.clipboard.writeText(this.encryptedHash());
      alert("Hash copied. Share it only with authorized recipients.");
    }
  }

  executeUnlock(): void {
    const hash = this.hashToDecrypt();
    const password = this.decryptPassword();
    
    if (!hash || !password) {
      alert("Please provide both hash and password.");
      return;
    }
    
    this.decryptedText.set('');
    this.decryptedImage.set('');
    this.showDecryptOutput.set(false);

    try {
      const cleanHash = atob(hash.replace("STX_TXT", "").replace("STX_IMG", ""));
      const decryptedBytes = CryptoJS.AES.decrypt(cleanHash, password + this.SALT);
      const decryptedData = decryptedBytes.toString(CryptoJS.enc.Utf8);

      if (!decryptedData) {
        throw new Error("Decryption failed");
      }
      
      this.showDecryptOutput.set(true);
      if (hash.startsWith("STX_IMG")) {
        this.decryptedImage.set(decryptedData);
      } else {
        this.decryptedText.set(decryptedData);
      }
    } catch (e) {
      console.error("Decryption error:", e);
      alert("Access Denied: Invalid Hash or Password.");
    }
  }

  downloadImage(): void {
    const src = this.decryptedImage();
    if (src) {
      const link = document.createElement('a');
      link.href = src;
      link.download = 'Editex_Recovered.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }

  openModal(type: ModalType): void {
    this.activeModal.set(type);
  }

  closeModal(): void {
    this.activeModal.set(null);
  }

  toggleChatbot(): void {
    this.isChatbotOpen.update(v => !v);
  }
}
